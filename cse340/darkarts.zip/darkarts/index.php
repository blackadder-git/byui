<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Course Syllabus: Regex</title>
    <meta name="description" content="Earn points for your house as you work your way through 7 years of RegEx curriculum">
    <link rel="shortcut icon" href="../favicon.ico">
    <link rel="apple-touch-icon" href="../apple-touch-icon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
    <style>
        body{padding:1em;font-size:2em}img{max-width:100%}li{list-style:none}ul#requirements li{list-style:disc}h3{margin-top:0}.yearHeading{background-color:pink;padding:1em}.quote{font-style:italic;font-weight:700}.hint{font-style:italic;margin-top:1em}body.Gryffindor,section.Gryffindor{background-image:linear-gradient(#dbab29,#c90909)}body.Hufflepuff,section.Hufflepuff{background-image:linear-gradient(#fce455,#786601)}body.Ravenclaw,section.Ravenclaw{background-image:linear-gradient(#508ca6,#00587e)}body.Slytherin,section.Slytherin{background-image:linear-gradient(#67a07a,#1d7239)}div.Gryffindor{background-color:#8b0000;color:#dbab29}div.Hufflepuff{background-color:#40410c;color:#fbd702}div.Ravenclaw{background-color:#00d5e5;color:#613e2e}div.Slytherin{background-color:#3ae371;color:#1d7239}form.Gryffindor{background-color:#8b0000}form.Hufflepuff{background-color:#40410c}form.Ravenclaw{background-color:#00d5e5}form.Slytherin{background-color:#3ae371}#house,#house_description div:nth-child(2){text-align:center}#house_description div:nth-child(2) img{margin-top:1em}#banners{display:grid;grid-template-columns:1fr 1fr 1fr 1fr}.cup{text-align:center;padding:1em}form{text-align:center;background-color:#0ff}input[type=checkbox]{-ms-transform:scale(2.5);-moz-transform:scale(2.5);-webkit-transform:scale(2.5);-o-transform:scale(2.5);transform:scale(2.5);margin-right:1em}input{max-width:100%}.panel div:nth-child(2){text-align:center}.pass{background-color:green}.fail{background-color:red}.hide{display:none}@media only screen and (min-width:33em){.panel{display:grid;grid-template-columns:3fr 1fr}.grading{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;text-align:center}.grading div img{max-width:50%}#house_description{display:grid;grid-template-columns:1fr 1fr}.panel{padding:1em}#crest{position:fixed;top:10px;right:10px}.grade{width:80%;border-radius:1em;padding:1em;margin-bottom:1em;margin:0 auto}form{max-width:80%;padding:1em;margin:0 auto}.cup img{margin-right:6.5em}}
    </style>
</head>
<body>
    <div><h1>Course Syllabus: Dark Arts - Regular Expressions</h1><span id="crest"></span><div>

    <h2>Overview</h2>
    Regular Expressions, commonly known as "regex" or "RegExp", are a formatted text strings used to find patterns in text. 
    Regular expressions are a powerful tools for effective and efficient text processing and manipulations. 
    For example, it can be used to verify whether the format of data i.e. name, email, phone number, etc. entered by the user 
    was correct or not, find or replace matching string within text content, and so on. 
    <a href="https://doc.laserfiche.com/laserfiche.documentation/en-us/Subsystems/ProcessAutomation/Content/Resources/Regular%20Expressions/Common-Regular-Expressions.htm" target="_blank" rel="noopener noreferrer">Common expressions</a>

    <h2>Requirements</h2>
    <ul id="requirements">
        <li>delimiters, a pattern and optional modifiers</li>
        <li>$exp = "/Hogwarts/i";</li>
        <li>In the example above, / is the delimiter, <strong>Hogwarts</strong> is the pattern that is being searched for, and i is a modifier that makes the search case-insensitive.</li>
        <li>The delimiter can be any character that is not a letter, number, backslash or space. The most common delimiter is the forward slash (/), but when your pattern contains forward slashes it is convenient to choose other delimiters such as # or ~.</li>
        <li>\ - use a backslash to search for special characters (., +, *, ?, ^, -, $, (, ), [, ], {, }, |, /, \)</li>
        <li><a href="https://www.w3schools.com/php/php_ref_regex.asp" target="_blank" rel="noopener noreferrer">More ...</a></li>
    </ul>

    <h2>URL Example</h2>
    /(?:http|https|ftp|mailto|file|data|irc):\/\/[A-Za-z0-9\-]{0,63}(\.[A-Za-z0-9\-]{0,63})+(:\d{1,4})?\/*(\/*[A-Za-z0-9\-._]+\/*)*(\?.*)?(#.*)?/

    <h2 class="house">Houses</h2>
    <div id="house" class="panel">
        <div id="house_description">
            <div>Where do you belong? <h3>Gryffindor, Hufflepuff, Ravenclaw, Slytherin?</h3>
                Find out, click the sorting hat and you will be placed in your house.
            </div>
            <div><img src="images/Hogwarts.png" ="Hogwarts house crests"></div>
        </div>
        <div id="sort">
            <img src="images/sorting-hat.png" alt="Sorting hat" title="Now when I call your name, you will come forth, &#013;I shall place the Sorting Hat on your head &#013;... and you will be sorted into your houses">
        </div>
    </div>

    <h2>Grading Model</h2>
    Triumphs will earn your House points, while any rule-breaking will lose you points. At the end of the year, the House with the most points is awarded the RegEx House Cup, a great honour.
    <div class="panel grading">
        <div id="Gryffindor">
            <img src="images/G.png" alt="Gryffindor banner"> <div class="points">0 points</div>
        </div>
        <div id="Hufflepuff">
            <img src="images/H.png" alt="Hufflepuff banner"> <div class="points">0 points</div>
        </div>
        <div id="Ravenclaw">
            <img src="images/R.png" alt="Ravenclaw banner"> <div class="points">0 points</div>
        </div>
        <div id="Slytherin">
            <img src="images/S.png" alt="Slytherin banner"> <div class="points">0 points</div>
        </div>
    </div>

    <h2>Course Summary</h2>
    <?php 
        require_once("regex.php"); 
        echo ($passed ? $passed : '<hr>');
    ?>

    <?php $currentYear = 1; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year One: Character Classes (or Bracket List)</h3>
            <div class="quote">
                This year is an introduction to the Dark Arts and how to defend against them. Therefore, we will not be learning any advanced spells, nor will we be discussing high level Dark magic. We will be sticking to basics and I ask that you not incorporate higher level Dark magic in your assignments until such time that you learn about them.
            </div>
        </div>
        <div class="panel">
            <div>
                <ul>
                    <li><label for="brackets"><input id="brackets" type="checkbox" disabled> [...] - Accept ANY ONE of the characters within brackets, e.g., [aeiou] matches "a", "e", "i", "o" or "u".</label></li>
                    <li><label for="notbrackets"><input id="notbrackets" type="checkbox" disabled> [^...] - NOT ONE of the characters, e.g., [^0-9] matches any non-digit.</label></li>
                    <li><label for="range"><input id="range" type="checkbox" disabled> [...-...] - Accept ANY ONE of the character in the range, e.g., [0-9] matches any digit; [A-Za-z] matches any uppercase or lowercase letters.</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?> "type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.php.net/manual/en/regexp.reference.character-classes.php" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" name="practice" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 2; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Two: Meta-characters</h3>
            <div class="quote">
                 Now — be warned! It is my job to arm you against the foulest creatures known to wizardkind! You may find yourselves facing your worst fears in this room. Know only that no harm can befall you whilst I am here. All I ask is that you remain calm. I must ask you not to scream. It might provoke them.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="period"><input id="period" type="checkbox" disabled> . - find any character, default [^\n]</label></li>
                    <li><label for="d"><input id="d" type="checkbox" disabled> \d - find a digit [0-9]</label></li>
                    <li><label for="D"><input id="D" type="checkbox" disabled> \D - find non-digit [^0-9]</label></li>
                    <li><label for="s"><input id="s" type="checkbox" disabled> \s - find whitespace [ \t\n\r\f\v]</label></li>
                    <li><label for="S"><input id="S" type="checkbox" disabled> \S - find non-whitespace [^ \t\n\r\f\v]</label></li>
                    <li><label for="w"><input id="w" type="checkbox" disabled> \w - find word [a-zA-Z0-9]</label></li>
                    <li><label for="W"><input id="W" type="checkbox" disabled> \W - find non-word [^a-zA-Z0-9]</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.php.net/manual/en/regexp.reference.meta.php" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 3; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Three: Position Anchors</h3>
            <div class="quote">
                Year Three will take us on a global expedition as we learn about the various Dark creatures that inhabit our world. We will be exploring what the creatures are and why they are considered Dark, covering a small amount of the lore that exists around them, and learning proper spells and techniques in order to defend ourselves against them.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="carrot"><input id="carrot" type="checkbox" disabled> ^ - match the beginning of the string</label></li>
                    <li><label for="dollar"><input id="dollar" type="checkbox" disabled> $ - match the end of the string</label></li>
                    <li><label for="b"><input id="b" type="checkbox" disabled> \b...\b - wrap a string you want to match e.g. \b<strong>Hagrid</strong>\b</label></li>
                    <li><label for="B"><input id="B" type="checkbox" disabled> \B...\B - inverse of \b, match must be inside a string</label></li>
                    <li><label for="A"><input id="A" type="checkbox" disabled> \A - match beginning like (^)</label></li>
                    <li><label for="z"><input id="Z" type="checkbox" disabled> \Z - match end (like $)</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://riptutorial.com/regex/example/6153/word-boundaries" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 4; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Four: Quantifiers (Greedy)</h3>
            <div class="quote">
                So — straight into it. Curses. They come in many strengths and forms. Now, according to the Ministry of Magic, I’m supposed to teach you countercurses and leave it at that. I’m not supposed to show you what illegal Dark curses look like until you’re in the sixth year. You’re not supposed to be old enough to deal with it till then. But Professor Dumbledore’s got a higher opinion of your nerves, he reckons you can cope, and I say, the sooner you know what you’re up against, the better.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="asteriskG"><input id="asteriskG" type="checkbox" disabled> n* - match as much of a string that contains zero or more n's</label></li>
                    <li><label for="plusG"><input id="plusG" type="checkbox" disabled> n+ - match as much of a string that contains at least one n</label></li>
                    <li><label for="questionG"><input id="questionG" type="checkbox" disabled> n? - match as much of a string that contains zero or one n's</label></li>
                    <li><label for="betweenG"><input id="betweenG" type="checkbox" disabled> n{x,y} - match as much of a string that contains between x and y n's (inclusive)</label></li>
                    <li><label for="atleastG"><input id="atleastG" type="checkbox" disabled> n{x,} - match as much of a string that contains at least x n's (n+)</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.rexegg.com/regex-quantifiers.html" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 5; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Five: Quantifiers (Lazy)</h3>
            <div class="quote">
                Well now, your teaching in this subject has been rather disrupted and fragmented, hasn’t it? The constant changing of teachers, many of whom do not seem to have followed any Ministry-approved curriculum, has unfortunately resulted in your being far below the standard we would expect to see in your O.W.L. year. You will be pleased to know, however, that these problems are now to be rectified. We will be following a carefully structured, theory-centred, Ministry-approved course of defensive magic this year.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="asteriskL"><input id="asteriskL" type="checkbox" disabled> n*? - match the min amount of string that contains zero or more n's</label></li>
                    <li><label for="plusL"><input id="plusL" type="checkbox" disabled> n+? - match the min amount of string that contains at least one n</label></li>
                    <li><label for="questionL"><input id="questionL" type="checkbox" disabled> n?? - match the min amount of string that contains zero or one n's</label></li>
                    <li><label for="betweenL"><input id="betweenL" type="checkbox" disabled> n{x,y}? - match the min amount of string that contains between x and y n's (inclusive)</label></li>
                    <li><label for="atleastL"><input id="atleastL" type="checkbox" disabled> n{x,}? - match the min amount of string that contains at least x n's (n+)</label></li>
                    <li><label for="exactlyL"><input id="exactlyL" type="checkbox" disabled> n{x} - match a string that contains exactly X n's</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.rexegg.com/regex-quantifiers.html" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 6; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Six: Modifiers</h3>
            <div class="quote">
                You have had five teachers in this subject so far, I believe. Naturally, these teachers will all have had their own methods and priorities. Given this confusion I am surprised so many of you scraped an O.W.L. in this subject. I shall be even more surprised if all of you manage to keep up with N.E.W.T. work, which will be much more advanced.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="insensitive"><input id="insensitive" type="checkbox" disabled> i - performs a case-insensitive search</label></li>
                    <li><label for="multiline"><input id="multiline" type="checkbox" disabled> m - perform a multiline search (^ and $ will match the beginning and ending of each line) e.g. /^And/m</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.php.net/manual/en/regexp.reference.meta.php" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 7; ?>
    <section id="curriculum<?php echo $currentYear; ?>"Test class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Year Seven: Grouping</h3>
            <div class="quote">
                In this final course for Defense Against the Dark Arts, we will be exploring the worst aspects of the Dark Arts. Using the lens of human rights, we will be looking at the most evil Dark Arts, exploring why they violate basic human rights, and how to defend ourselves against them if it is at all possible. This will be the most rigorous term in Defense Against the Dark Arts, so do not enter the classroom lightly or with a faint heart.
            </div>
        </div>    
        <div class="panel">
            <div>
                <ul>
                    <li><label for="pipe"><input id="pipe" type="checkbox" disabled> ...|... - find a match for any pattern separated by the pipe symbol</label></li>
                    <li><label for="capture"><input id="capture" type="checkbox" disabled> (...) - put a part of the pattern in parentheses to create a capturing group</label></li>
                    <li><label for="named"><input id="named" type="checkbox" disabled> (?&lt;name&gt;...) Assign a capturing group a name by putting the ?&lt;name&gt; immediately after the opening parentheses</label></li>
                </ul>

                <?php if (!empty($message) && $year == 'year' . $currentYear) echo '<div>' . $message . '</div>'; ?>
                <form method="get" id="year<?php echo $currentYear; ?>Practice" class="hide">
                    Write a pattern to match the string: <strong><span id="year<?php echo $currentYear; ?>SpellSpan">______________</span></strong><br>
                    <p>
                        <label for="pattern<?php echo $currentYear; ?>">Regex: <input id="pattern<?php echo $currentYear; ?>" type="text" name="pattern" required autocomplete="off"></label>
                        <input type="hidden" id="year<?php echo $currentYear; ?>Spell" name="string">
                        <input type="hidden" name="year" value="year<?php echo $currentYear; ?>">
                        <input type="submit" value="Test Expressio">
                        <a href="https://www.phptutorial.net/php-tutorial/regex-capturing-groups/" target="_blank" rel="noopener noreferrer" class="hint">Hint</a>
                    </p>
                </form>
            </div>
            <div>
                <img src="images/dada<?php echo $currentYear; ?>.png" alt="Year <?php echo $currentYear; ?> instructor">
                <input id="year<?php echo $currentYear; ?>" class="practice" type="button" value="Practice">
            </div>
        </div>
    </section>

    <?php $currentYear = 8; ?>
    <section id="curriculum<?php echo $currentYear; ?>" class="hide">
        <div id="year<?php echo $currentYear; ?>anchor" class="yearHeading">
            <h3>Graduation</h3>
            <div id="winner" class="quote"></div>
        </div>
        <div id="banners"></div>    
        <div class="cup">
            <img src="images/trophy.png" alt="House Cup">
            <div><strong>Congratulations</strong></div>
        </div>
    </section>

    <script>
        const houses = ['Gryffindor', 'Hufflepuff', 'Ravenclaw', 'Slytherin'];
        const housePoints = [2, 2, 3, 3, 3, 5, 5, 5, 10, 10, 10, 20, 20, 40, 40, 50, 60];

        // this gets set after someone clicks the sorting hat
        const house = localStorage.getItem('RegExHouse');

        /**********************************************************************
        // get a random word to match
        ***********************************************************************/
        function getRandomWord(id) {
            let words = [];
            // https://www.harrypotterfanzone.com/defence-against-the-dark-arts-teachers/
            switch(id) {
                case 'year1': // 1991
                    words = ['1st year', 'Class 104', 'Classroom 3C', 'Philosopher\'s Stone', '⚡🤓', '🦉', '🏰🧙‍♂️', '🦁🦨🦅🐍', '🍫🐸', '9🚂3/4', 'Quirinus Quirrell', 'Albania', 'turban', '3 headed dog', 'Lily', 'Voldemort', 'Troll', 'Neville Longbottom', 'Quidditch Through the Ages', 'Transfiguration', 'Voldemort'];
                    break;
                case 'year2': // 1992
                    words = ['2nd year', 'Class 104', 'Classroom 3C', 'Chamber of Secrets', '📘🧦', 'Gilderoy Lockhard', 'memory charm', 'Cornish Pixies', 'Ginny Weasley',  'mandrakes',  'Tom Riddle\'s soul', 'Voldemort'];
                    break;
                case 'year3': // 1993
                    words = ['3rd year', 'Class 104', 'Classroom 3C', 'Prisoner of Azkaban', '🌕🐺', '🏟🧹👦🏉👦🧹', 'Remus Lupin', 'Patronus Charm', 'werewolf', 'Wolfsbane', 'Dementor', 'shrinking solution', 'boggart', 'insufferable know-it-all', 'crocodile heart', 'Quidditch', 'Voldemort'];
                    break;
                case 'year4': // 1994
                    words = ['4th year', 'Class 104', 'Classroom 3C', 'Goblet of Fire', '🏆🔥', 'Bartemius Crouch Jr.', 'Alastor \"Mad-Eye\" Moody', 'Unforgivable Curses', 'Dementor\'s Kiss', 'Polyjuice Potion', 'Witch Weekly', 'rose bushes', 'Goblet of Fire', 'Densaugeo', 'Voldemort'];
                    break;
                case 'year5': // 1995
                    words = ['5th year', 'Class 104', 'Classroom 3C', 'Order of the Phoenix', '🦅🔥', 'Dolores Umbridge', 'O.W.L.s', 'Ministry of Magic', 'Forbidden Forest', 'centaurs', 'Battle of the Department of Mysteries', 'Trip Jinx', 'Thestrals', 'Wilbert Slinkhard', 'Bowtruckles', 'Voldemort'];
                    break;
                case 'year6': // 1996
                    words = ['6th year', 'Class 104', 'Classroom 3C', 'Half-Blood Prince', '🐍', '⚗️', '🤴🩸', '⚰️🍽️', 'Severus Snape', 'N.E.W.T.', 'Death Eater', 'Start-of-Term Feast', 'Voldemort', 'Do you really think that the Dark Lord has not asked me each and every one of those questions?<br>\nAnd do you really think that, had I not been able to give satisfactory answers,<br>\nI would be sitting here talking to you?'];
                    break;
                case 'year7': // 1997
                    words = ['7th year', 'Class 104', 'Classroom 3C', 'Deathly Hallows', '👽', '☠️', 'Amycus Carrow', 'Cruciatus Curse', '7 Horcruxes', 'bezoar', 'Golpalott\'s Third Law', 'Amortentia', 'Voldemort'];
                    break;
                default:
            }
            return words[Math.floor(Math.random() * words.length)];
        }

        /**********************************************************************
        // listen for the click of each practice button
        ***********************************************************************/
        const practices = document.querySelectorAll('.practice');
        practices.forEach(practice => {
            practice.addEventListener('click', (e) => {
                
                // clear grade
                let grade = document.querySelector(".grade");
                if (grade) {
                    grade.remove();
                }
                
                const id = e.target.getAttribute('id');
                const word = getRandomWord(id);
                
                // hidden input, pass to php
                document.querySelector(`#${id}Spell`).value = word;
                // show word
                document.querySelector(`#${id}SpellSpan`).innerHTML = word;
                document.querySelector(`#${id}Practice`).classList.remove('hide'); // show section
            });
        });

        /**********************************************************************
        // check for completed assignment
        ***********************************************************************/
        function correctAssignment() {
            let completedRegEx = JSON.parse(localStorage.getItem('RegExAssignments'));
            if (completedRegEx == null) {
                completedRegEx = [];
            }

            const passed = document.querySelector('#passed'); // php creates this element if passed
            if (passed) {
                const hasPassed = passed.getAttribute('data-passed');

                // in to check key: https://stackoverflow.com/questions/1098040/checking-if-a-key-exists-in-a-javascript-object
                // includes to check value: https://www.w3schools.com/jsref/jsref_includes_array.asp
                if (hasPassed != 'fail' && (completedRegEx.includes(hasPassed))) {
                    alert('You have already completed this assignment: ' + hasPassed);
                }
                else {
                    if (hasPassed != 'fail') {
                        // alert(hasPassed);
                        const points = getHousePoints();

                        // TODO: style as a dialog
                        alert(`Well done ${points} points for ${house}`);

                        addHousePoints(points, house);

                        // mark assignment complete
                        completedRegEx.push(hasPassed);

                        // save grade
                        localStorage.setItem('RegExAssignments', JSON.stringify(completedRegEx));
                    }
                    else {
                        // deduct points for incorrect answer
                        const tempHouses = houses.filter(tempHouse => tempHouse != house);
                        const tempHouse = tempHouses[Math.floor(Math.random() * tempHouses.length)];
                        let points = getHousePoints();

                        // TODO: style as a dialog
                        alert(`${points} points deducted from house ${house} and awarded to ${tempHouse}`);

                        addHousePoints(-points, house);
                        addHousePoints(points, tempHouse);
                    }
                }
            }

            // show all completed assignments
            console.log(completedRegEx);
            if (completedRegEx.length > 0) {
                completedRegEx.forEach(completed => {
                    document.querySelector(`#${completed}`).checked = true;
                });

                checkGraduation(completedRegEx);
            }
        }

        /**********************************************************************
        // mark next term open once student has graduated
        ***********************************************************************/
        function checkGraduation(completedRegEx) {
            // show next year(s) when previous is complete
            // https://www.gavsblog.com/blog/find-single-or-array-of-values-in-javascript-array-using-includes
            // registration
            if (!(house == null)) {
                document.querySelector('#curriculum1').classList.remove('hide');
            }
            // year1
            if (['brackets', 'notbrackets', 'range'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum2').classList.remove('hide');
            }
            // year2
            if (['period', 'd', 'D', 's', 'S', 'w', 'W'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum3').classList.remove('hide');
            }
            // year3
            if (['carrot', 'dollar', 'b', 'B', 'A', 'z'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum4').classList.remove('hide');
            }
            // year4
            if (['asteriskG', 'plusG', 'questionG', 'atleastG', 'betweenG'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum5').classList.remove('hide');
            }
            // year5
            if (['asteriskL', 'plusL', 'questionL', 'atleastL', 'betweenL', 'exactlyL'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum6').classList.remove('hide');
            }
            // year6
            if (['insensitive', 'multiline', 'utf8'].every(i => completedRegEx.includes(i))) {
                document.querySelector('#curriculum7').classList.remove('hide');
            }
            // year7
            if (['pipe', 'named', 'capture'].every(i => completedRegEx.includes(i))) {
                const pointsRegEx = JSON.parse(localStorage.getItem('RegExPoints'));
                let winner = '';
                let points = 0;
                for (const [key, value] of Object.entries(pointsRegEx)) {
                    if (value > points) {
                        points = value;
                        winner = key;
                    }
                }
                document.querySelector("#banners").innerHTML = `<img src="images/${winner[0]}.png" alt="${winner} banner"><img src="images/${winner[0]}.png" alt="${winner} banner"><img src="images/${winner[0]}.png" alt="${winner} banner"><img src="images/${winner[0]}.png" alt="${winner} banner">`;
                document.querySelector("#winner").innerHTML = `The winner of this year's RegEx House Cup is ... ${winner} with ${points} points`; // <img src="images/${winner}_crest.png" alt="${winner}">
                document.querySelector('#curriculum8').classList.add(winner);
                document.querySelector('#year8anchor').classList.add(winner);
                document.querySelector('#curriculum8').classList.remove('hide');
            }   
        }

        /**********************************************************************
        // get number of points to award or subtract
        ***********************************************************************/
        function getHousePoints() {
            return housePoints[Math.floor(Math.random() * houses.length)];
        }

        // update house points
        function addHousePoints(points, house) {
            let pointsRegEx = JSON.parse(localStorage.getItem('RegExPoints'));
            pointsRegEx[house] += points;

            localStorage.setItem('RegExPoints', JSON.stringify(pointsRegEx));
        }

        // show house points
        function showHousePoints() {
            // show house points
            const pointsRegEx = JSON.parse(localStorage.getItem('RegExPoints'));
            const pointsRegExArray = Object.entries(pointsRegEx);

            // https://www.samanthaming.com/tidbits/76-converting-object-to-array/ (object to array)
            pointsRegExArray.forEach(([house, points]) => {
                // TODO: fails if element isn't found
                document.querySelector(`#${house} div.points`).textContent = `${points} points`;
            });
        }

        /**********************************************************************
        // universal updates: background, headings
        ***********************************************************************/
        function themePage(house) {
            document.querySelector('body').classList = ''; // remove all
            // color body
            document.querySelector('body').classList.add(house);
            // color headings
            let h2 = document.querySelectorAll('.yearHeading');
            h2.forEach(element => {
                element.classList.add(house);
            });
            let forms = document.querySelectorAll('form');
            forms.forEach(element => {
                element.classList.add(house);
            });
        }

        /**********************************************************************
        // update page to reflect chosen house and points
        ***********************************************************************/
        function showHouse(house) {
            // change crest
            document.querySelector('body').classList.add(house);

            // change content
            const history = {Gryffindor: "Founded by Godric Gryffindor. Gryffindor instructed the Sorting Hat to choose students possessing characteristics he most valued, such as courage, chivalry, nerve and determination,[4] to be sorted into his house." +
                                         "<br><br>" +
                                         "The emblematic animal was a lion, and its colours were scarlet and gold. Sir Nicholas de Mimsy-Porpington, also known as \"Nearly Headless Nick\", was the House ghost." +
                                         "<br><br>" +
                                         "Gryffindor corresponded roughly to the element of fire, and it was for this reason that the colours scarlet and gold were chosen to represent the house. The colour of fire corresponded to that of a lion as well, with scarlet representing the mane and tail and gold representing the coat.",

                             Hufflepuff: "Its founder was the medieval witch Helga Hufflepuff. Hufflepuff was the most inclusive among the four houses, valuing hard work, dedication, patience, loyalty, and fair play rather than a particular aptitude in its members." +
                                         "<br><br>" +
                                         "The emblematic animal is a badger. The Head of Hufflepuff was Pomona Sprout, and the Fat Friar was the House's patron ghost." +
                                         "<br><br>" +
                                         "Hufflepuff corresponded roughly to the element of earth, and it was for that reason that the House colours were chosen: yellow represents wheat, while black is emblematic of soil. The Hufflepuff point hourglass contains yellow diamonds. Students sorted into Hufflepuff often demonstrated exceptional abilities in Herbology, owing to their correspondence to earth.",

                             Ravenclaw: "Its founder was the medieval witch Rowena Ravenclaw. Members of this house were characterised by their wit, learning, and wisdom. The emblematic animal symbol was an eagle, and blue and bronze were its colours. The Head of Ravenclaw was Filius Flitwick, and the House ghost was the Grey Lady, real name Helena Ravenclaw, daughter of Rowena." +
                                        "<br><br>" +
                                        "Ravenclaw corresponded roughly to the element of air, and it was for that reason that the House colours were chosen; blue and bronze represented the sky and eagle feathers respectively, both having much to do with air. The Ravenclaw points hourglass contained blue sapphires.",

                             Slytherin: "Founded by Salazar Slytherin. In establishing the house, Salazar instructed the Sorting Hat to pick students who had a few particular characteristics he most valued. Those characteristics included cunning, resourcefulness, leadership, and ambition." +
                                        "<br><br>" +
                                        "The emblematic animal of the house is a snake and the house's colours are green and silver which corresponded with waters around lakes and lochs often being green, and silver being often associated with grey rainwater. The patron ghost of the house was the Bloody Baron." +
                                        "<br><br>" +
                                        "Slytherin corresponded roughly with the element of water due to serpents being commonly associated with the sea and lochs in western European mythology, as well as serpents being physically fluid and flexible animals. Similarly, in Celtic mythology, water is seen as a portal to another world, leading some to speculate that the element was chosen to symbolise many Slytherins' hope for a pure-blood only community."
                   };

            // add house name, description, and crest
            document.querySelector('.house').innerHTML = `House ${house}`;
            document.querySelector('#house').innerHTML = `<div id="house_sorted">
                                                            ${history[house]}
                                                          </div>
                                                          <div>
                                                             <img src="images/${house}_crest.png" alt="House ${house} crest">
                                                          </div>`;
            themePage(house);
            showHousePoints();
        }

        /**********************************************************************
        // choose house (once) when the user clicks the sorting hat
        ***********************************************************************/
        document.querySelector('#sort').addEventListener('click', sortHouse);
        function sortHouse () {
            const house = houses[Math.floor(Math.random() * houses.length)];
            
            // make the choice persistent
            localStorage.setItem('RegExHouse', house);
            
            let description = '<div>Ah, right then. Mmm...right. ';
            switch(house) {
                case 'Gryffindor':
                    description += 'Okay, if you\'re sure, <h2>Gryffindor!</h2></div><div><blockquote>Where dwell the brave at heart,<br>Their daring, nerve and chivalry<br>Set Gryffindors apart.</blockquote></div>';
                    break;
                case 'Hufflepuff':
                    description += 'I know, <h2>Hufflepuff!</h2></div> <div><blockquote>Where they are just and loyal<br>Those patient Hufflepuffs are true<br>And unafraid of toil.</blockquote></div>';
                    break;
                case 'Ravenclaw':
                    description += 'Ha, I know just what to do with you, <h2>Ravenclaw!</h2></div> <div><blockquote>If you’ve a ready mind<br>Where those of wit and learning<br>Will always find their kind.</blockquote></div>';
                    break;
                case 'Slytherin':
                    description += '<h2>Slytherin!</h2></div> <div><blockquote>You’ll make your real friends<br>Those cunning folk use any means<br>To achieve their ends.</blockquote></div>';
                    break;
            }

            themePage(house);

            // add house crest & description
            document.querySelector('#sort img').setAttribute('src', `images/${house}_crest.png`);
            document.querySelector('#house_description').innerHTML = description;

            // the sorting hat has spoken
            document.querySelector('#sort').removeEventListener('click', sortHouse);

            // let the games begin, create a place to store points
            const pointsRegEx = {"Gryffindor":0, "Hufflepuff":0, "Ravenclaw":0, "Slytherin":0}; // create associative array with braces
            localStorage.setItem('RegExPoints', JSON.stringify(pointsRegEx));

            // to store completed assignments
            const completedRegEx = [];
            localStorage.setItem('RegExAssignments', JSON.stringify(completedRegEx));

            // show curriculum
            document.querySelector('#curriculum1').classList.remove('hide');
        }

        /**********************************************************************
        // animate scroll
        // https://stackoverflow.com/questions/17733076/smooth-scroll-anchor-links-without-jquery
        ***********************************************************************/
        function animate(elem, style, unit, from, to, time, prop) {
            if (!elem) {
                return;
            }
            let start = new Date().getTime(),
                timer = setInterval(function() {
                let step = Math.min(1, (new Date().getTime() - start) / time);
                if (prop) {
                    elem[style] = (from + step * (to - from)) + unit;
                }
                else {
                    elem.style[style] = (from + step * (to - from)) + unit;
                }
                if (step === 1) {
                    clearInterval(timer);
                }
            }, 25);
            if (prop) {
                elem[style] = from + unit;
            }
            else {
                elem.style[style] = from + unit;
            }
        }

        /**********************************************************************
        // once page is ready, scroll to current year
        ***********************************************************************/
        window.onload = function() {
            //const house = JSON.parse(localStorage.getItem('RegExHouse'));
            if (house != null) {
                showHouse(house); // modify house
                // show curriculum
                document.querySelector('#curriculum1').classList.remove('hide');                
            }

            // https://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
            const params = new Proxy(new URLSearchParams(window.location.search), {
                get: (searchParams, prop) => searchParams.get(prop),
            });

            // Get the value of "some_key" in eg "https://example.com/?some_key=some_value"
            const year = params.year;
            // alert(year);

            const target = document.querySelector(`#${year}anchor`);
            if (target != null) {
                animate(document.scrollingElement || document.documentElement, "scrollTop", "", 0, target.offsetTop, 500, true);
            }
        };

        // check and correct any assignment that has been submitted
        correctAssignment();

    </script>

    <!--
        IMAGES & CONTENT

        Sorting hat
        https://www.pngmart.com/image/175110

        Logos
        https://www.kindpng.com/imgv/iibxbTh_harry-potter-houses-hd-png-download/

        Banners
        https://pngset.com/download-free-png-bpptd

        Content
        https://www.tutorialrepublic.com/php-tutorial/php-regular-expressions.php

        Fandom (text)
        https://www.fandom.com/community-creation-policy
        https://www.hogwartsishere.com/courses/
    -->
</body>
</html>