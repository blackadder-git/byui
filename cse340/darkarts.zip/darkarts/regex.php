<?php

    $year = filter_input(INPUT_GET, 'year');
    $pattern = filter_input(INPUT_GET, 'pattern');
    $string = filter_input(INPUT_GET, 'string');
    $message = null;
    $passed = null;

    // the pattern delimiter cannot be alphanumeric, backslash or space
    if ($pattern && !ctype_alnum($pattern[0]) && $pattern[0] != '\\' && $pattern[0] != ' ') {
        $match = '';
        $assignment = '';
        $hint = '';
        $matches = '';

        // store matches
        $match = preg_match($pattern, $string, $matches);
        /* preg_filter(), preg_grep(), preg_last_error(), preg_match(), preg_match_all(), preg_replace(), preg_replace_callback(), preg_replace_callback_array(), preg_split(), preg_quote() */

        if ($match) {
            switch ($year) {
                // character classes
                case 'year1':
                    // echo 'DEBUG: year 1';
                    // pattern (not brackets)
                    if (strpos($pattern, '^') && $pattern[1] == '[' && $pattern[strlen($pattern) - 2] == ']') {
                        $assignment = 'notbrackets';
                    }
                    // pattern (range brackets)
                    else if (strpos($pattern, '-') && $pattern[1] == '[' && $pattern[strlen($pattern) - 2] == ']') {
                        $assignment = 'range';
                    }
                    // pattern (brackets)
                    else if ($pattern[1] == '[' && $pattern[strlen($pattern) - 2] == ']') {
                        $assignment = 'brackets';
                    }
                    else {
                        $hint = "<div class=\"hint\">Did you forget to include [] brackets inside your delimiters?</div>";
                    }
                    break;
                // meta-characters
                case 'year2':
                    // echo 'DEBUG: year 2'; 
                    // pattern (.)
                    if (strpos($pattern, '.')) {
                        $assignment = 'period';
                    }
                    // pattern (\d)
                    else if (strpos($pattern, '\d')) {
                        $assignment = 'd';
                    }
                    // pattern (\D)
                    else if (strpos($pattern, '\D')) {
                        $assignment = 'D';
                    }
                    // pattern (\s)
                    else if (strpos($pattern, '\s')) {
                        $assignment = 's';
                    }
                    // pattern (\S)
                    else if (strpos($pattern, '\S')) {
                        $assignment = 'S';
                    }
                    // pattern (\w)
                    else if (strpos($pattern, '\w')) {
                        $assignment = 'w';
                    }
                    // pattern (\W)
                    else if (strpos($pattern, '\W')) {
                        $assignment = 'W';
                    }
                    else {
                        // TODO: $hint = "add hint";
                    }
                    break;
                case 'year3':
                    // echo 'DEBUG: year 3';
                    // pattern x (find a match at the beginning of the string)
                    if (strpos($pattern, '^') && $pattern[1] == '^') { // first position should be delimiter
                        $assignment = 'carrot';
                    }
                    // pattern x (find a match at the end of the string)
                    else if (strpos($pattern, '$') && $pattern[strlen($pattern) - 2] == '$') { // last position should be delimiter
                        $assignment = 'dollar';
                    }
                    // pattern x (match is found as a word)
                    else if (substr_count($pattern, '\b') == 2) {
                        $assignment = 'b';
                    }
                    // pattern x (match exists inside a word)
                    else if (substr_count($pattern, '\B') == 2) {
                        $assignment = 'B'; 
                    }
                    else if (strpos($pattern, '\A')) {
                        $assignment = 'A'; 
                    }
                    else if (strpos($pattern, '\Z')) {
                        $assignment = 'Z'; 
                    }
                    else {
                        $hint = "<div class=\"hint\">Make sure that ^ and \A begin your pattern, $ and \z end it, \b encloses a string and \B encloses a substring</div>";
                    }
                    break;
                case 'year4':
                    // echo 'DEBUG: year 4';
                    // pattern x (find a match for any pattern separated by the pipe symbol)
                    if (strpos($pattern, '*')) {
                        $assignment = 'asteriskG';
                    }
                    // pattern x (find a match at the beginning of the string)
                    else if (strpos($pattern, '+')) {
                        $assignment = 'plusG';
                    }
                    // pattern x (find a match at the end of the string)
                    else if (strpos($pattern, '?')) {
                        $assignment = 'questionG';
                    }
                    // pattern x (n{x,} match any string that contains a at least X n's (x+))
                    else if ((strpos($pattern, '{') !== false) && (strpos($pattern, '}', strpos($pattern, '{')) !== false) && (substr($pattern, strpos($pattern, '}') -1, 1) == ',')) { // is , -1 from }
                        $assignment = 'atleastG';
                    }
                    // pattern x (n{x,y} match any string that contains a between X and Y n's (inclusive))
                    else if ((strpos($pattern, '{') !== false) && (strpos($pattern, '}', strpos($pattern, '{')) !== false) && (strpos($pattern, ',', strpos($pattern, '{')) !== false)) { // after { but doesn't check before }
                        $assignment = 'betweenG';
                    }
                    else {
                        // TODO: $hint = "add hint";
                    }
                    break;
                case 'year5':
                    // echo 'DEBUG: year 5';
                    // pattern x (find a match for any pattern separated by the pipe symbol)
                    if (strpos($pattern, '*?')) {
                        $assignment = 'asteriskL';
                    }
                    // pattern x (find a match at the beginning of the string)
                    else if (strpos($pattern, '+?')) {
                        $assignment = 'plusL';
                    }
                    // pattern x (find a match at the end of the string)
                    else if (strpos($pattern, '??')) {
                        $assignment = 'questionL';
                    }
                    // pattern x (n{x,} match any string that contains a at least X n's (x+))
                    else if ((strpos($pattern, '{') !== false) && (strpos($pattern, '}?', strpos($pattern, '{')) !== false) && (substr($pattern, strpos($pattern, '}?') -1, 1) == ',')) { // is , -1 from }
                        $assignment = 'atleastL';
                    }
                    // pattern x (n{x,y} match any string that contains a between X and Y n's (inclusive))
                    else if ((strpos($pattern, '{') !== false) && (strpos($pattern, '}?', strpos($pattern, '{')) !== false) && (strpos($pattern, ',', strpos($pattern, '{')) !== false)) { // after { but doesn't check before }
                        $assignment = 'betweenL';
                    }
                    // pattern x (n{x} match any string that contains exactly X n's)
                    else if ((strpos($pattern, '{') !== false) && strpos($pattern, '}', strpos($pattern, '{'))) {
                        $assignment = 'exactlyL';
                    }
                    else {
                        $hint = "Did you forget to add a ? to the end and make the match lazy?";
                    }
                    break;
                case 'year6':
                    // echo 'DEBUG: year 6';  
                    // pattern x (i)
                    if ($pattern[strlen($pattern) - 1] == 'i') {
                        $assignment = 'insensitive';
                    }
                    // pattern x (m)
                    else if ($pattern[strlen($pattern) - 1] == 'm') {
                        $assignment = 'multiline';
                    }
                    else {
                        // TODO: $hint = "add hint";
                    }
                    break;
                case 'year7':
                    // echo 'DEBUG: year 7';
                    // pattern x (find a match for any pattern separated by the pipe symbol)
                    if (strpos($pattern, '|')) {
                        $assignment = 'pipe';
                    }
                    // pattern x (?<..>...)
                    else if ((strpos($pattern, '(?<') !== false) && (strpos($pattern, ')', strpos($pattern, '(?<')))) { // doesn't check for closing >
                        $assignment = 'named';
                    }
                    // pattern x (...)
                    else if ((strpos($pattern, '(') !== false) && (strpos($pattern, ')', strpos($pattern, '(')) !== false )) {
                        $assignment = 'capture';
                    }
                    else {
                        // TODO: $hint = "add hint";
                    }
                    break;
                default:
                    // echo 'default';
            } // end siwtch

            if ($assignment) {
                $message = "<div class=\"pass grade\">Correct, <strong>$pattern</strong> matches <strong>$string</strong><br>" . print_r($matches, true) . "</div>";

                // create element for JavaScript detection
                $passed = "<hr id=\"passed\" data-passed=\"$assignment\">";
            }
            else {
                // valid but didn't match any of this years expressions
                $message = "<div class=\"fail grade\">Your RegEx was valid but <strong>$pattern</strong> does not match this year's string <strong>$string</strong>$hint</div>";
                $passed = "<hr id=\"passed\" data-passed=\"fail\" data-year=\"$year\">";
            }
        }
        else {
            // invalid expression
            switch($year) {
                case 'year1':
                    $hint = "<div class=\"hint\">Did you forget to include [] brackets inside your delimiters?</div>";
                    break;
                default:
                    $hint = "<div class=\"hint\">Did you forget to include delimiters?</div>";
            }
            $message = "<div class=\"fail grade\">No, no, no, <strong>$pattern</strong> does not match: <strong>$string</strong>$hint</div>";
            $passed = "<hr id=\"passed\" data-passed=\"fail\" data-year=\"$year\">";
        }

        //echo "DEBUG pattern: $pattern : $match";
    }
    else {
        $message = "<div class=\"fail grade\">Error, did you forget the delimiter cannot be alphanumeric, backslash or space?</div>";
    }
?>